//package lession5.classroom;
//
///**
// * �̲�55ҳ��ϰ��
// * 
// * @Title: Test55.java
// * @Package lession5.classroom
// * @Description: TODO(��һ�仰�������ļ���ʲô)
// * @author: ������18 17����
// * @date: 2018��10��21�� ����9:49:03
// */
//public class Test55 {
//	public static void main(String[] args) {
//		int i1 = 100;
//		int i2 = i1;
//		System.out.println("i1: " + i1);
////		System.out.println("i2: " + i2);
//		i2 = 200;
//		System.out.println("i1: " + i1);
//		System.out.println("i2: " + i2);
//		Circle4 c1 = new Circle4(10.5, 20, 30);
//		Circle4 c2 = c1;
//		System.out.print("c1: " + c1.getX() + ", ");
//		System.out.print(c1.getY() + ", ");
//		System.out.println(c1.getRadius() + ", ");
//		System.out.print("c2: " + c2.getX() + ", ");
//		System.out.print(c2.getY() + ", ");
//		System.out.println(c2.getRadius() + ", ");
//		c2.setX(100);
//		c2.setY(200);
//		c2.setRadius(50);
//		System.out.print("c1: " + c1.getX() + ", ");
//		System.out.print(c1.getY() + ", ");
//		System.out.println(c1.getRadius() + ", ");
//		System.out.print("c2: " + c2.getX() + ", ");
//		System.out.print(c2.getY() + ", ");
//		System.out.println(c2.getRadius() + ", ");
//	}
//
//}
