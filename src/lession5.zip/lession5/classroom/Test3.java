package lession5.classroom;

public class Test3 {

	public static void main(String[] args) {
		Circle3 c1 = new Circle3(10);
		Circle3 c2 = new Circle3(20);

		System.out.println(c1.getArea());
		System.out.println(c1.getPerimeter());

		System.out.println(c2.getArea());
		System.out.println(c2.getPerimeter());
	}

}
